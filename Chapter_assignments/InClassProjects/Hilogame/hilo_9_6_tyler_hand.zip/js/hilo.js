console.log("javascript is working...")

class Game{
    /*
        Secret number - number the player is guessing
        numebrofguesses - number ove atempts
        guessArray - values the user guessed so far
        gamerunning - tells if the games is running or not
    */ 
   constructor(){
        this.secretNumber = 0;
        console.log(this.secretNumber)
        this.numOfGuesses = 0;
        this.guessArray = [];
        this.gameRunning = false;

   }

   newGame(){
        this.secretNumber = Math.floor(Math.random() * 100 + 1)
        console.log(this.secretNumber)
        this.numOfGuesses = 0;
        this.guessArray = [];
        this.gameRunning = true;

   }


}
function main(){
 game = new Game(); // game is a global variable; mo help for it
    
}
function startGame(won){
   if (game.gameRunning){
        if (!won){
            if(confirm("Really Quit? Are you sure?")==false){
                return;
            }else{
                //Quitting
                var start = document.getElementById("start");
                start.innerHTML = "Start Game";
                game.gameRunning = false;
                
                var prompt = document.getElementById("prompt");
                prompt.innerHTML = 'Press "Start Game" to begin';

                var playerInput = document.getElementsByClassName("playerInput");
                for(i = 0; i < playerInput.length; i++){
                    playerInput[i].style.visibility = "hidden";
                }
            }
        }

   }
   else{//game is not running
        game.newGame();
        var start = document.getElementById("start");
        start.innerHTML= "Quit Game";

        var prompt = document.getElementById("prompt");
        prompt.innerHTML = "Enter your fisrt guess below";

        var playerInput = document.getElementsByClassName("playerInput");
        for(i = 0; i < playerInput.length; i++){
            playerInput[i].style.visibility = "visible";
        }
        updateScore();
   }

}
function updateScore(){
    var results = document.getElementById("results");
    results.innerHTML = "Number of Guesses " + game.numOfGuesses;

    var playerInput = document.getElementById("playerInput");
    playerInput.value = "";
    playerInput.focus();
}

function checkGuess(){
    console.log("checking guess");

    // code for checking guess
    // it must check for all possable input errors, 
    // missing input, wrong data type, input out of range, non int numbers, 
    // and numbers previosly guessed

    //get the function
    var playerInput = document.getElementById("playerInput").value;
    console.log("playerInput: " + playerInput);

    // missing input
    if (playerInput == ""){
        alert("You need to enter a guess");
        return;
    }
    if (isNaN(playerInput)){
        alert("That is not a number");
        return;
    }
    if (playerInput > 100 || playerInput < 1 ){
        alert("Out of range");
        return;
    }
    if (playerInput % 1 != 0){
        alert("Whole numbers only");
        return;
    }
    for(i=0;i< game.guessArray.length;i++){
        if(playerInput == game.guessArray[i])
            alert("You Have guessed that number before");
            return;
    }
    // since we are passed all the error traps, we can record the guess
    game.guessArray.push(playerInput);
    game.numOfGuesses++;
    updateScore();


}