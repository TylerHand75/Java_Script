descriptions = {
    "st01": "description of store 01. it can be this long.",
    "st02": "description of store 02. it can be this long.",
    "st03": "description of store 03. it can be this long.",
    "st04": "description of store 04. it can be this long.",
    "st05": "description of store 05. it can be this long.",
    "st06": "description of store 06. it can be this long.",
    "st07": "description of store 07. it can be this long.",
    "st08": "description of store 08. it can be this long.",
    "st09": "description of store 09. it can be this long.",
    "st10": "description of store 10. it can be this long.",
    "st11": "description of store 11. it can be this long.",
    "st12": "description of store 12. it can be this long.",
    "st13": "description of store 13. it can be this long.",
    "st14": "description of store 14. it can be this long.",
    "st15": "description of store 15. it can be this long.",
    "st16": "description of store 16. it can be this long.",
    "st17": "description of store 17. it can be this long.",
    "st18": "description of store 18. it can be this long.",
    "st19": "description of store 19. it can be this long.",
    "st20": "description of store 20. it can be this long.",
    "st21": "description of store 21. it can be this long.",
    "st22": "description of store 22. it can be this long.",
    "st23": "description of store 23. it can be this long.",
    "st24": "description of store 24. it can be this long.",
    "st25": "description of store 25. it can be this long.",
    "st26": "description of store 26. it can be this long.",
    "st27": "description of store 27. it can be this long.",
    "st28": "description of store 28. it can be this long.",
    "st29": "description of store 29. it can be this long.",
    "st30": "description of store 30. it can be this long.",
    "st31": "description of store 31. it can be this long.",
    "st32": "description of store 32. it can be this long.",
    "st33": "description of store 33. it can be this long.",
    "st34": "description of store 34. it can be this long.",
    "st35": "description of store 35. it can be this long.",
    "st36": "description of store 36. it can be this long.",

}
Titles = {
    "st01": "I am Store 01.",
    "st02": "I am Store 02.",
    "st03": "I am Store 03.",
    "st04": "I am Store 04.",
    "st05": "I am Store 05.",
    "st06": "I am Store 06.",
    "st07": "I am Store 07.",
    "st08": "I am Store 08.",
    "st09": "I am Store 09.",
    "st10": "I am Store 10.",
    "st11": "I am Store 11.",
    "st12": "I am Store 12.",
    "st13": "I am Store 13.",
    "st14": "I am Store 14.",
    "st15": "I am Store 15.",
    "st16": "I am Store 16.",
    "st17": "I am Store 17.",
    "st18": "I am Store 18.",
    "st19": "I am Store 19.",
    "st20": "I am Store 20.",
    "st21": "I am Store 21.",
    "st22": "I am Store 22.",
    "st23": "I am Store 23.",
    "st24": "I am Store 24.",
    "st26": "I am Store 26.",
    "st27": "I am Store 27.",
    "st28": "I am Store 28.",
    "st29": "I am Store 29.",
    "st30": "I am Store 30.",
    "st31": "I am Store 31.",
    "st32": "I am Store 32.",
    "st33": "I am Store 33.",
    "st34": "I am Store 34.",
    "st35": "I am Store 35.",
    "st36": "I am Store 36.",

}




console.log("Javascript is woooking");

$(document).ready(function () {
    console.log("Jquery is ready")

    //<a class="dot" style="left: 135px; top:160px;"></a>
    // $("#map").click(function(e){
    //     var pos = '<a class="dot" style="left:' + (e.offsetX - 12)
    //      + 'px; top:' 
    //      + (e.offsetY - 12)
    //      +'px; "></a>';

    //     console.log(pos);
    // });

    $("#map a.dot").click(function () {
        $("#map a.dot").removeClass("selected");
        $(this).addClass("selected");

        //which dot is clicked

        var store = $(this).attr("store");
        showDescription(store);




    });
function showDescription(descriptionToShow){
$("#descriptionbox p").text(descriptions[descriptionToShow]);
$("desriptionbox h4").text(Titles[descriptionToShow]);
$("desriptionbox img").attr(src = "images/" + descriptionToShow + ".jpg");
}


});