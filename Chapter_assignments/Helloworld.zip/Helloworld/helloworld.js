$(document).ready(function() {
    $('#hello').dialog({
        modal : true,
        resizable : false,
        dragable : false,
        hide : "explode"
    });
  }); // end ready