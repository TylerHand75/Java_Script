$(document).ready(function() {

    $('[title]').tooltip();


}); // end ready