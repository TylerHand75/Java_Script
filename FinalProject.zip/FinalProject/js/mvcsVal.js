$(document).ready(function(){

    $(".selected").click(function(){
        $(this).removeClass("selected");
    });

    $(".unselected").click(function(){
        $(this).addClass("selected");
        $(this).removeClass("unselected");
    });
    $('.rating').buttonset();




});