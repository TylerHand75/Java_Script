console.log("javascript is working...")

class Game{
    /*
        Secret number - number the player is guessing
        numebrofguesses - number ove atempts
        guessArray - values the user guessed so far
        gamerunning - tells if the games is running or not
    */ 
   constructor(){
        this.secretNumber = 0;
        console.log(this.secretNumber)
        this.numOfGuesses = 0;
        this.guessArray = [];
        this.gameRunning = true;

   }

   newGame(){
        this.secretNumber = Math.floor(Math.random() * 100 + 1)
        console.log(this.secretNumber)
        this.numOfGuesses = 0;
        this.guessArray = [];
        this.gameRunning = true;
   }


}
function main(){
    game = new Game(); // game is a global variable; mo help for it
    
}