console.log("js works");


//One way for jquery
// function readyHandler() {
//     console.log("jQuery is ready");
// }

// $(document).ready(readyHandler);

//other way
$(document).ready(function(){           //anonymous function
    console.log("jquery ready");

    $("#message").css("color", "red");
});